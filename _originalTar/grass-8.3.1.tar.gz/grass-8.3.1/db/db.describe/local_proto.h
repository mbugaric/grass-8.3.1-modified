#ifndef __LOCAL_PROTO_H__
#define __LOCAL_PROTO_H__

int print_priv(char *, int);
int print_column_definition(dbColumn *);
int print_table_definition(dbDriver *, dbTable *);

#endif /* __LOCAL_PROTO_H__ */
