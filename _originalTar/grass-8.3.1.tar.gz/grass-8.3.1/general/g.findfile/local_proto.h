/* element.c */
void list_elements(void);
/* int check_element(const char *); */
