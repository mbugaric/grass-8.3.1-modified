extern char *map_name;
extern int color;
extern float size;
extern int style;
extern int type;
extern int is_fp;
extern int nodata;
extern int nsteps;
extern int cat_ranges;

#define PIE   1
#define BAR   2
#define COUNT 3
#define AREA  4
#define YES   1
#define NO    0
