void plot(double, double, double, double, int, int, double, const char *);
