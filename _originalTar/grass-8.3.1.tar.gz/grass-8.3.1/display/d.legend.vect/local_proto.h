#define BUFFSIZE 512

/* draw.c */
void draw(char *, double, double, char *, int, int, int, int, int, char *, int,
          char *, int, char *, int, int, int, char *);
