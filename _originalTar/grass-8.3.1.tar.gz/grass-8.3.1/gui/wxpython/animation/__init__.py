all = [
    "nviztask",
    "temporal_manager",
    "dialogs",
    "mapwindow",
    "g.gui.animation",
    "controller",
    "anim",
    "toolbars",
    "utils",
    "frame",
]
